package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.StopFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.de.GermanAnalyzer;
import org.apache.lucene.analysis.ja.JapaneseAnalyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.synonym.SynonymGraphFilter;
import org.apache.lucene.analysis.synonym.SynonymMap;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.ByteBuffersDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.util.CharsRef;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.PriorityQueue;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Wiki {
    private static final Logger logger = LoggerFactory.getLogger(Wiki.class);

    static Map<String, Directory> languageDirectories = new HashMap<>();
    static Map<String, IndexWriter> languageWriters = new HashMap<>();

    public static class TermFreq implements Comparable<TermFreq> {
        String term;
        long freq;

        public TermFreq(String term, long freq) {
            this.term = term;
            this.freq = freq;
        }

        public int compareTo(TermFreq other) {
            return Long.compare(freq, other.freq);
        }
    }

    public static void main(String[] args) throws Exception {
        setupDirectoriesAndWriters();

        String[] englishPageTitles = {"Physical Fitness", "Atmosphere", "Climate", "Culture"};
        String[] englishPageTitles2 = {"Austin, Texas", "Houston", "San Antonio", "Dallas", "Fort Worth, Texas"};
        String[] japanesePageTitles = {"夏", "中国暦", "雨水"};
        String[] germanPageTitles = {"Anamnesis", "Transzendenz", "Psychologie"};

        String synonymFilePath = "/Users/badisa/synonym_list.txt";

        // Index englishPageTitles
        indexDocuments(englishPageTitles, "English", synonymFilePath);

        // Index otherLanguagePageTitles
        indexDocuments3(japanesePageTitles, "Japanese");
        indexDocuments3(germanPageTitles, "German");

        // Set up the new directory and writer for englishPageTitles2
        setupEnglish2DirectoryAndWriter();

        // Index englishPageTitles2
        indexDocuments2(englishPageTitles2, "English2", synonymFilePath);


        String searchQueryEng = "region";
        String searchQueryJpn = "雨水";
        String searchQueryGer = "Bedingungen";
        List<Document> initialSearchResultsEng = searchIndex(searchQueryEng, "English");
        List<Document> initialSearchResultsJpn = searchIndex(searchQueryJpn, "Japanese");
        List<Document> initialSearchResultsGer = searchIndex(searchQueryGer, "German");

        printSearchResults("English", searchQueryEng, initialSearchResultsEng);
        printSearchResults("Japanese", searchQueryJpn, initialSearchResultsJpn);
        printSearchResults("German", searchQueryGer, initialSearchResultsGer);

        String[] searchTermsEng = {"physical", "fitness"};
        String[] searchTermsJpn = {"夏（なつ", "は"};
        String[] searchTermsGer = {"Zugriff", "darauf"};
        List<Document> searchPhraseResultsEng = searchIndexWithPhrase(searchTermsEng, "English");
        List<Document> searchPhraseResultsJpn = searchIndexWithPhrase(searchTermsJpn, "Japanese");
        List<Document> searchPhraseResultsGer = searchIndexWithPhrase(searchTermsGer, "German");

        printSearchResultsForPhraseQuery("English", searchPhraseResultsEng);
        printSearchResultsForPhraseQuery("Japanese", searchPhraseResultsJpn);
        printSearchResultsForPhraseQuery("German", searchPhraseResultsGer);

        closeWriters();
    }

    private static void setupDirectoriesAndWriters() throws IOException {
        languageDirectories.put("English", new ByteBuffersDirectory());
        languageDirectories.put("Japanese", new ByteBuffersDirectory());
        languageDirectories.put("German", new ByteBuffersDirectory());

        StandardAnalyzer englishAnalyzer = new StandardAnalyzer();
        JapaneseAnalyzer japaneseAnalyzer = new JapaneseAnalyzer();
        GermanAnalyzer germanAnalyzer = new GermanAnalyzer();

        languageWriters.put("English", new IndexWriter(languageDirectories.get("English"), new IndexWriterConfig(englishAnalyzer)));
        languageWriters.put("Japanese", new IndexWriter(languageDirectories.get("Japanese"), new IndexWriterConfig(japaneseAnalyzer)));
        languageWriters.put("German", new IndexWriter(languageDirectories.get("German"), new IndexWriterConfig(germanAnalyzer)));
    }

    static Directory english2Directory;
    static IndexWriter english2Writer;

    private static void setupEnglish2DirectoryAndWriter() throws IOException {
        english2Directory = new ByteBuffersDirectory();
        StandardAnalyzer englishAnalyzer = new StandardAnalyzer();
        english2Writer = new IndexWriter(english2Directory, new IndexWriterConfig(englishAnalyzer));
    }

    public static void indexDocuments(String[] pageTitles, String language, String synonymFilePath) throws Exception {
        Analyzer analyzer = getAnalyzerForLanguage(language, synonymFilePath);
        IndexWriter writer = languageWriters.get(language);

        // For each page title, get the page content and index the document
        for (String pageTitle : pageTitles) {
            // Fetch the page content
            String pageContent = fetchWikipediaPageContent(pageTitle, language);
            // Index the document
            Document doc = new Document();
            doc.add(new TextField("title", pageTitle, Field.Store.YES));
            doc.add(new TextField("content", pageContent, Field.Store.YES));
            writer.addDocument(doc);
        }
        // Commit the changes but don't close the writer
        writer.commit();
    }
    public static void indexDocuments2(String[] pageTitles, String language, String synonymFilePath) throws Exception {
        Analyzer analyzer = getAnalyzerForLanguage(language, synonymFilePath);
        IndexWriter writer = english2Writer;

        for (String pageTitle : pageTitles) {
            String pageContent = fetchWikipediaPageContent(pageTitle, language);
            Document doc = new Document();
            doc.add(new TextField("title", pageTitle, Field.Store.YES));
            doc.add(new TextField("content", pageContent, Field.Store.YES));
            writer.addDocument(doc);
        }

        writer.commit();
    }

    public static void indexDocuments3(String[] pageTitles, String language) throws Exception {
        Analyzer analyzer = getAnalyzerForLanguage(language);
        IndexWriter writer = languageWriters.get(language);

        // For each page title, get the page content and index the document
        for (String pageTitle : pageTitles) {
            // Fetch the page content
            String pageContent = fetchWikipediaPageContent(pageTitle, language);
            // Index the document
            Document doc = new Document();
            doc.add(new TextField("title", pageTitle, Field.Store.YES));
            doc.add(new TextField("content", pageContent, Field.Store.YES));
            writer.addDocument(doc);
        }
        // Commit the changes but don't close the writer
        writer.commit();
    }

    private static void closeWriters() throws IOException {
        for (IndexWriter writer : languageWriters.values()) {
            writer.close();
        }
        english2Writer.close();
    }

    private static void printSearchResults(String language, String query, List<Document> results) {
        logger.info(language + " SearchResults for Query '" + query + "':");
        for (Document result : results) {
            logger.info("Title: " + result.get("title"));
            logger.info("Content: " + result.get("content"));
        }
    }

    private static void printSearchResultsForPhraseQuery(String language, List<Document> results) {
        logger.info(language + " Search Results for Phrase Query:");
        for (Document result : results) {
            logger.info("Title: " + result.get("title"));
            logger.info("Content: " + result.get("content"));
        }
    }

    public static List<Document> searchIndex(String queryString, String language) throws IOException, ParseException {
        Analyzer analyzer = getAnalyzerForLanguage(language);
        QueryParser queryParser = new QueryParser("content", analyzer);
        Query query = queryParser.parse(queryString);

        IndexReader indexReader = DirectoryReader.open(languageDirectories.get(language));
        IndexSearcher searcher = new IndexSearcher(indexReader);
        TopDocs topDocs = searcher.search(query, 10);
        ScoreDoc[] scoreDocs = topDocs.scoreDocs;

        List<Document> searchResults = new ArrayList<>();
        for (ScoreDoc scoreDoc : scoreDocs) {
            int docId = scoreDoc.doc;
            Document document = searcher.doc(docId);
            searchResults.add(document);
        }

        indexReader.close();

        return searchResults;
    }

    public static List<Document> searchIndexWithPhrase(String[] terms, String language) throws IOException {
        Analyzer analyzer = getAnalyzerForLanguage(language);

        IndexReader indexReader = DirectoryReader.open(languageDirectories.get(language));
        IndexSearcher searcher = new IndexSearcher(indexReader);

        // Tokenize the search terms using the respective analyzer
        List<String> tokenizedTerms = new ArrayList<>();
        TokenStream tokenStream = analyzer.tokenStream("content", new StringReader(String.join(" ", terms)));
        CharTermAttribute charTermAttribute = tokenStream.addAttribute(CharTermAttribute.class);
        tokenStream.reset();
        while (tokenStream.incrementToken()) {
            tokenizedTerms.add(charTermAttribute.toString());
        }
        tokenStream.end();
        tokenStream.close();

        PhraseQuery.Builder builder = new PhraseQuery.Builder();
        for (String term : tokenizedTerms) {
            builder.add(new Term("content", term));
        }
        PhraseQuery pq = builder.build();

        TopDocs topDocs = searcher.search(pq, 10);
        ScoreDoc[] scoreDocs = topDocs.scoreDocs;

        List<Document> searchResults = new ArrayList<>();
        for (ScoreDoc scoreDoc : scoreDocs) {
            int docId = scoreDoc.doc;
            Document document = searcher.doc(docId);
            searchResults.add(document);
        }

        indexReader.close();

        return searchResults;
    }

    public static String fetchWikipediaPageContent(String pageTitle, String language) throws Exception {
        String langCode = "en";
        switch (language) {
            case "Japanese":
                langCode = "ja";
                break;
            case "German":
                langCode = "de";
                break;
        }

        String apiUrlString = "https://" + langCode + ".wikipedia.org/w/api.php?" +
                "format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&titles=" +
                URLEncoder.encode(pageTitle, "UTF-8");

        URL apiUrl = new URL(apiUrlString);
        HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

        connection.setRequestMethod("GET");
        connection.connect();

        int responseCode = connection.getResponseCode();

        if (responseCode == 200) {
            InputStream inputStream = connection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder jsonStringBuilder = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                jsonStringBuilder.append(line);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonStringBuilder.toString());
            JsonNode pages = jsonNode.get("query").get("pages");
            JsonNode page = pages.elements().next();
            JsonNode extract = page.get("extract");

            return extract.asText();
        } else {
            throw new Exception("Error: API request failed with response code " + responseCode);
        }
    }

    public static void getTopTerms(String language) throws Exception {
        PriorityQueue<TermFreq> queue = new PriorityQueue<>();
        CharArraySet stopWords = EnglishAnalyzer.getDefaultStopSet();

        Directory directory = language.equals("English2") ? english2Directory : languageDirectories.get(language);

        try (IndexReader indexReader = DirectoryReader.open(directory)) {
            for (int i = 0; i < indexReader.maxDoc(); i++) {
                Terms terms = indexReader.getTermVector(i, "content");
                if (terms == null) {
                    continue;
                }
                TermsEnum termsEnum = terms.iterator();
                BytesRef term;
                while ((term = termsEnum.next()) != null) {
                    String termText = term.utf8ToString();
                    if (!stopWords.contains(termText)) {
                        long termFreq = termsEnum.totalTermFreq();
                        queue.add(new TermFreq(termText, termFreq));
                        if (queue.size() > 50) {
                            queue.poll();
                        }
                    }
                }
            }
        }

        logger.info("Terms in the queue: " + queue.size()); // New logging statement

        logger.info("Top 50 terms for " + language + " are:");
        while (!queue.isEmpty()) {
            TermFreq termFreq = queue.poll();
            logger.info("Term: " + termFreq.term + ", Frequency: " + termFreq.freq);
        }
    }

    private static void printTopTerms(PriorityQueue<TermFreq> queue) {
        int count = 1;
        while (!queue.isEmpty()) {
            TermFreq termFreq = queue.poll();
            logger.info("Term " + count + ": " + termFreq.term + ", Frequency: " + termFreq.freq);
            count++;
        }
    }

    public static Analyzer getAnalyzerForLanguage(String language) {
        switch (language) {
            case "Japanese":
                return new JapaneseAnalyzer();
            case "German":
                return new GermanAnalyzer();
            default:
                return new StandardAnalyzer();
        }
    }

    public static Analyzer getAnalyzerForLanguage(String language, String synonymFilePath) {
        final CharArraySet stopSet = EnglishAnalyzer.getDefaultStopSet();
        SynonymMap synonymMap;
        try (BufferedReader reader = new BufferedReader(new FileReader(synonymFilePath))) {
            SynonymMap.Builder builder = new SynonymMap.Builder(true);
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split(",");
                String word = words[0];
                for (int i = 1; i < words.length; i++) {
                    String synonym = words[i];
                    builder.add(new CharsRef(word.replace(" ", "\u0000")), new CharsRef(synonym.replace(" ", "\u0000")), true);
                }
            }
            synonymMap = builder.build();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return new Analyzer() {
            @Override
            protected TokenStreamComponents createComponents(String fieldName) {
                final Tokenizer source = new StandardTokenizer();
                TokenStream filter = new LowerCaseFilter(source);
                filter = new StopFilter(filter, stopSet);
                filter = new SynonymGraphFilter(filter, synonymMap, true);
                return new TokenStreamComponents(source, filter);
            }
        };
    }
}
