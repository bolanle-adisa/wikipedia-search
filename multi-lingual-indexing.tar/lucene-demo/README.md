# lucene-demo
To demonstrate my understanding of multi lingual indexing.
